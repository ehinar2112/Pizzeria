function aumentarImagen(imagen) {
    imagen.style.transform = "scale(1.2)";
    imagen.style.transition = "transform 0.3s";
}

function restaurarImagen(imagen) {
    imagen.style.transform = "scale(1)";
}
