<?php
class Conexion {
    private $host = "192.168.56.1";
    private $db = "pizzeria"; // Nombre de la base de datos
    private $user = "user"; // Usuario de la base de datos
    private $password = "12345"; 
    private $charset = "utf8mb4";

    public function conectar() {
        try {
            $dsn = "mysql:host=" . $this->host . ";port=3306;dbname=" . $this->db . ";charset=" . $this->charset;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            ];

            $pdo = new PDO($dsn, $this->user, $this->password, $options);
            return $pdo;
        } catch (PDOException $e) {
            die("Error al conectar con la base de datos: " . $e->getMessage());
        }
    }
}
?>
